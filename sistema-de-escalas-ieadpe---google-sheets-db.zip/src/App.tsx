import React, { useState, useEffect, useMemo } from "react";
import { 
  Calendar, 
  Users, 
  MapPin, 
  Settings, 
  Save, 
  Plus, 
  Trash2, 
  ChevronRight, 
  Printer, 
  Download,
  AlertCircle,
  Database,
  Search,
  CheckCircle2,
  RefreshCw
} from "lucide-react";
import { format, addDays, startOfWeek, parseISO, isWithinInterval } from "date-fns";
import { ptBR } from "date-fns/locale";
import { motion, AnimatePresence } from "motion/react";

// --- Types ---
interface Obreiro {
  nome: string;
  cargo: string;
  congregacao: string;
}

interface Congregacao {
  nome: string;
}

interface EscalaItem {
  congregacao: string;
  codigo: string;
  escalados: string[];
}

interface EscalaOficialData {
  [dia: string]: EscalaItem[];
}

interface EscalaLocalItem {
  categoria: string;
  data: string;
  local: string;
  codigo: string;
  escalados: string[];
}

interface Evento {
  id: string;
  data: string;
  descricao: string;
  cc: string;
  congregacao: string;
}

interface TipoCulto {
  nome: string;
  codigo: string;
}

interface RegraCulto {
  congregacao: string;
  dia: string;
  regraSemana: string[]; // [week1_code, week2_code, etc]
}

// --- Constants ---
const CODIGOS_TRABALHO = [
  "01. ORAÇÃO","02. PREGAÇÃO","03. CEIA","04. DOUTRINA","05. ADMINISTRATIVO","06. ESTUDO MOCIDADE","07. ANIV. CAMP. EVANG.","08. EST. ÓRGÃO LOUVOR","09. ANIV. ÓRGÃO LOUVOR","10. CULTO MOCIDADE","11. ABERTURA FESTIV.","12. CULTO DA FAMÍLIA","13. MANHÃ MISIONÁRIA","14. CULTO EVANGELÍSTICO","15. ANIV. C. O.","16. ANIV. TEMPLO","17. CULTO DE MISSÕES","18. ESTUDO P/ CASAIS","19. ESTUDO P/ CRIANÇAS","20. ESTUDO P/ ADOLESCENTES","21. ENCONTRO DE JOVENS","22. SEMIN. P/ DISCIPULADO","23. SIMPÓSIO EVANGELÍSMO","24. PLANTÃO RÁDIO BOAS NOVAS","25. ANIV. UNIÃO ADOLESCENTES","26. EST.P/ PAIS ADOLESCENTES","27. APOIO CONGREGAÇÃO","28. BATISMO TEMPLO CENTRAL","29. PRÉ-CONGRESSO","30. CONFERÊNCIA MISSIONÁRIA","31. CONGRESSO MOCIDADE","32. CONGRESSO ADOLESCENTES","33. CONGRESSO MULHERES","34. LEITURA EM C. O.","35. AÇÃO DE GRAÇAS","36. ESCOLA ANIMADA","37. CRUZADA EVANGELÍSTICA","38. LEITURA ANIV. C. O.","39. LEITURA ANIV. TEMPLO","40. MINISTRO PLANTÃO T.C.","41. PRESBÍTERO RECEPCIONISTA T.C.","42. VIGÍLIA DE ANO","43. ANIV. CONJUNTO MUSICAL","44. ANIV. CORAL","45. SIMPÓSIO DE DOUTRINA","46. NOITE MISSIONÁRIA","47. CULTO FESTIVO","48. ESTUDO P/ PROFESSORES","49. REUN. EQ. APOIO CASAIS","50. ANIV. C. O. I.","51. CONFERÊNCIA EBD","52. ABERTURA ESCOLA BÍBLICA","53. EST. ESCOLA BÍBLICA","54. ENS. ESCOLA BÍBLICA","55. INAUG. ÓRGÃO LOUVOR","56. ESTUDO BIBLICO","57. CULTO PROATI","58. PALAVRA CULTO VESPERTINO","59. SEMINÁRIO PARA A FAMILIA","60. SECADEAP FAMILIA","61. PONTO DE PREGAÇÃO","62. CULTO DE VIGÍLIA","63. CULTO. CAMP. EVANGEL.","64. FORMATURA DISIPULADO","65. CULTO DO REENCONTRO","66. PROJEFÉRIAS","67. ORAÇÃO DA CAMPANHA","68. ENCONTRO DE CRIANÇAS","69. INAUGURAÇÃO DE TEMPLO","70. ANIV. DO PROATI","71. CULTO JOVEM","72. ENCONTRO DE COMISSÕES","73. ENC. CAMP. EVANGELIZADORAS","74. CULTO MATUTINO"
];

const DIAS_SEMANA_OFICIAL = [
  { 
    id: "segunda", 
    label: "Segunda-feira - Noite", 
    filtros: ["Chã do Conselho 01", "Monte das Oliveiras", "Av. Brasil", "Engenho Vinagre", "Penedinho"] 
  },
  { 
    id: "terca", 
    label: "Terça-feira - Noite", 
    filtros: ["Templo Matriz"] 
  },
  { 
    id: "quarta", 
    label: "Quarta-feira", 
    filtros: ["Templo Matriz", "Monte das Oliveiras", "Monte Carmelo", "Av. Brasil", "Nova Canaã", "Itapipiré", "Quinze", "Lot. Bom Jesus", "Belo Oriente", "Jardim Nova Esperança", "Engenho Vinagre", "Três Ladeiras", "Vila Canaã", "Caraú", "Penedinho", "Chã do Conselho 01", "Chã do Conselho 02", "Lot. Fontes de Aldeia", "Alto Planalto", "Itaboraí"] 
  },
  { 
    id: "quintaManha", 
    label: "Quinta-feira (Manhã)", 
    filtros: ["Templo Matriz"] 
  },
  { 
    id: "quintaTarde", 
    label: "Quinta-feira (Tarde)", 
    filtros: ["Templo Matriz"] 
  },
  { 
    id: "quintaNoite", 
    label: "Quinta-feira (Noite)", 
    filtros: ["Quinze", "Três Ladeiras", "Belo Oriente", "Nova Canaã", "Lot. Fontes de Aldeia", "Lot. Bom Jesus", "Itaboraí"] 
  },
  { 
    id: "sexta", 
    label: "Sexta-feira (Noite)", 
    filtros: ["Monte Carmelo", "Jardim Nova Esperança", "Itapipiré", "Alto Planalto", "Vila Canaã", "Chã do Conselho 02"] 
  },
  { id: "sabado", label: "Sábado", filtros: [] },
  { id: "domingoManha", label: "Domingo (Manhã)", filtros: [] },
  { id: "domingoNoite", label: "Domingo (Noite)", filtros: [] },
];

const CARGOS = ["Pr.", "Pb.", "Dc.", "Aux.", "Aux. Local."];

const CONGREGACOES_PADRAO = [
  "Templo Matriz",
  "Monte das Oliveiras",
  "Monte Carmelo",
  "Av. Brasil",
  "Nova Canaã",
  "Itapipiré",
  "Quinze",
  "Lot. Bom Jesus",
  "Belo Oriente",
  "Jardim Nova Esperança",
  "Engenho Vinagre",
  "Três Ladeiras",
  "Vila Canaã",
  "Caraú",
  "Penedinho",
  "Chã do Conselho 01",
  "Chã do Conselho 02",
  "Lot. Fontes de Aldeia",
  "Alto Planalto",
  "Itaboraí"
];

const OBREIROS_PADRAO: Obreiro[] = [
  { nome: "Severino Guilhermino", cargo: "Pr.", congregacao: "Templo Matriz" },
  { nome: "Amauri Pereira", cargo: "Pb.", congregacao: "Av. Brasil" },
  { nome: "Ednaldo Antônio", cargo: "Pb.", congregacao: "Belo Oriente" },
  { nome: "Edmilson Clemente", cargo: "Pb.", congregacao: "Nova Canaã" },
  { nome: "Luiz José", cargo: "Pb.", congregacao: "Chã do Conselho 01" },
  { nome: "Rogério Brito", cargo: "Pb.", congregacao: "Itaboraí" },
  { nome: "Marcos Henrique", cargo: "Pb.", congregacao: "Itapipiré" },
  { nome: "Otoniel Luiz", cargo: "Pb.", congregacao: "Lot. Fontes de Aldeia" },
  { nome: "Elias Alberto", cargo: "Pb.", congregacao: "Templo Matriz" },
  { nome: "Herivelton Marculino", cargo: "Pb.", congregacao: "Templo Matriz" },
  { nome: "Jair Domingos", cargo: "Pb.", congregacao: "Templo Matriz" },
  { nome: "Manassés Pereira", cargo: "Pb.", congregacao: "Templo Matriz" },
  { nome: "Vitor Edson", cargo: "Pb.", congregacao: "Templo Matriz" },
  { nome: "Antônio Narciso", cargo: "Pb.", congregacao: "Monte Carmelo" },
  { nome: "Gilcelio Felipe", cargo: "Pb.", congregacao: "Monte Carmelo" },
  { nome: "Pedro José", cargo: "Pb.", congregacao: "Monte das Oliveiras" },
  { nome: "Antônio Alexandre", cargo: "Pb.", congregacao: "Quinze" },
  { nome: "Espedito Gomes", cargo: "Pb.", congregacao: "Quinze" },
  { nome: "João Firmino", cargo: "Pb.", congregacao: "Quinze" },
  { nome: "Leonardo Manoel", cargo: "Pb.", congregacao: "Vila Canaã" },
  { nome: "Givanildo Olímpio", cargo: "Dc.", congregacao: "Alto Planalto" },
  { nome: "Joseny Cândido", cargo: "Dc.", congregacao: "Av. Brasil" },
  { nome: "Kleitonlee Marcionilo", cargo: "Dc.", congregacao: "Av. Brasil" },
  { nome: "Waltermy Vieira", cargo: "Dc.", congregacao: "Av. Brasil" },
  { nome: "Daniel Domingos", cargo: "Dc.", congregacao: "Belo Oriente" },
  { nome: "José Anísio", cargo: "Dc.", congregacao: "Belo Oriente" },
  { nome: "João Severino", cargo: "Dc.", congregacao: "Lot. Bom Jesus" },
  { nome: "Lucas Gabriel", cargo: "Dc.", congregacao: "Lot. Bom Jesus" },
  { nome: "Nílson Carlos", cargo: "Dc.", congregacao: "Lot. Bom Jesus" },
  { nome: "Antônio Neto", cargo: "Dc.", congregacao: "Nova Canaã" },
  { nome: "José Domingos", cargo: "Dc.", congregacao: "Nova Canaã" },
  { nome: "Carlos Bone", cargo: "Dc.", congregacao: "Chã do Conselho 01" },
  { nome: "Diogo Santana", cargo: "Dc.", congregacao: "Chã do Conselho 01" },
  { nome: "Dorgival Gervásio", cargo: "Dc.", congregacao: "Chã do Conselho 01" },
  { nome: "Josivaldo Mariano", cargo: "Dc.", congregacao: "Chã do Conselho 01" },
  { nome: "Marcos Cavalcante", cargo: "Dc.", congregacao: "Chã do Conselho 01" },
  { nome: "Samuel Amaro", cargo: "Dc.", congregacao: "Chã do Conselho 01" },
  { nome: "José Santiago", cargo: "Dc.", congregacao: "Itapipiré" },
  { nome: "Valter Lopes", cargo: "Dc.", congregacao: "Lot. Fontes de Aldeia" },
  { nome: "Anílton Antônio", cargo: "Dc.", congregacao: "Templo Matriz" },
  { nome: "Antônio Figueiredo", cargo: "Dc.", congregacao: "Templo Matriz" },
  { nome: "Ezequiel Eduardo", cargo: "Dc.", congregacao: "Templo Matriz" },
  { nome: "Helton Carvalho", cargo: "Dc.", congregacao: "Templo Matriz" },
  { nome: "José Carlos", cargo: "Dc.", congregacao: "Templo Matriz" },
  { nome: "José Joaquim", cargo: "Dc.", congregacao: "Templo Matriz" },
  { nome: "José Menezes", cargo: "Dc.", congregacao: "Templo Matriz" },
  { nome: "Maciel Evaristo", cargo: "Dc.", congregacao: "Templo Matriz" },
  { nome: "Manuel Elias", cargo: "Dc.", congregacao: "Templo Matriz" },
  { nome: "Roberto Antônio", cargo: "Dc.", congregacao: "Templo Matriz" },
  { nome: "Rosemiro Francisco", cargo: "Dc.", congregacao: "Templo Matriz" },
  { nome: "Severino José", cargo: "Dc.", congregacao: "Templo Matriz" },
  { nome: "Damião Arruda", cargo: "Dc.", congregacao: "Monte Carmelo" },
  { nome: "Evanilson Pereira", cargo: "Dc.", congregacao: "Monte das Oliveiras" },
  { nome: "Antônio Gomes", cargo: "Dc.", congregacao: "Quinze" },
  { nome: "José Gonçalves", cargo: "Dc.", congregacao: "Quinze" },
  { nome: "Severino Gomes", cargo: "Aux.", congregacao: "Alto Planalto" },
  { nome: "Zequias Alves", cargo: "Dc.", congregacao: "Alto Planalto" },
  { nome: "Benjamin Alexandre", cargo: "Dc.", congregacao: "Av. Brasil" },
  { nome: "Cláudio Félix", cargo: "Aux.", congregacao: "Belo Oriente" },
  { nome: "Jefferson Balbino", cargo: "Aux.", congregacao: "Belo Oriente" },
  { nome: "Valderli Herculano", cargo: "Aux.", congregacao: "Belo Oriente" },
  { nome: "Waldemir Herculano", cargo: "Aux.", congregacao: "Belo Oriente" },
  { nome: "Edinael Eliel", cargo: "Aux.", congregacao: "Lot. Bom Jesus" },
  { nome: "José Henrique", cargo: "Aux.", congregacao: "Lot. Bom Jesus" },
  { nome: "Cleiton Gonçalves", cargo: "Aux.", congregacao: "Nova Canaã" },
  { nome: "Fábio Feliciano", cargo: "Aux.", congregacao: "Nova Canaã" },
  { nome: "Raú Ferreira", cargo: "Aux.", congregacao: "Nova Canaã" },
  { nome: "Severino Maurício", cargo: "Aux.", congregacao: "Nova Canaã" },
  { nome: "José Hélio", cargo: "Dc.", congregacao: "Nova Canaã" },
  { nome: "Bruno Bezerra", cargo: "Aux.", congregacao: "Chã do Conselho 01" },
  { nome: "Dorgivânio Gervásio", cargo: "Aux.", congregacao: "Chã do Conselho 01" },
  { nome: "Jessé Sabino", cargo: "Aux.", congregacao: "Chã do Conselho 01" },
  { nome: "Luiz Cavalcante", cargo: "Aux.", congregacao: "Chã do Conselho 01" },
  { nome: "Maurício Avelino", cargo: "Aux.", congregacao: "Chã do Conselho 01" },
  { nome: "Oseias Amaro", cargo: "Aux.", congregacao: "Chã do Conselho 01" },
  { nome: "Ozeias Júnior", cargo: "Aux.", congregacao: "Chã do Conselho 01" },
  { nome: "Paulo Henrique", cargo: "Aux.", congregacao: "Chã do Conselho 01" },
  { nome: "Rogério Lira", cargo: "Aux.", congregacao: "Chã do Conselho 01" },
  { nome: "Sebastião Francisco", cargo: "Aux.", congregacao: "Chã do Conselho 01" },
  { nome: "Valmir Gervásio", cargo: "Aux.", congregacao: "Chã do Conselho 01" },
  { nome: "Paulo Cândido", cargo: "Aux.", congregacao: "Itaboraí" },
  { nome: "Paulo Carlos", cargo: "Aux.", congregacao: "Itaboraí" },
  { nome: "Ricardo Florentino", cargo: "Aux.", congregacao: "Itaboraí" },
  { nome: "Genival Severino", cargo: "Aux.", congregacao: "Itapipiré" },
  { nome: "José Célio", cargo: "Aux.", congregacao: "Itapipiré" },
  { nome: "Ricardo Júnior", cargo: "Aux.", congregacao: "Itapipiré" },
  { nome: "Sandro Fernandes", cargo: "Aux.", congregacao: "Itapipiré" },
  { nome: "Wellington José", cargo: "Aux.", congregacao: "Itapipiré" },
  { nome: "Rodrigo Siqueira", cargo: "Dc.", congregacao: "Itapipiré" },
  { nome: "Adriano Barbosa", cargo: "Aux.", congregacao: "Lot. Fontes de Aldeia" },
  { nome: "Raison José", cargo: "Aux.", congregacao: "Lot. Fontes de Aldeia" },
  { nome: "Antônio Barbosa", cargo: "Aux.", congregacao: "Templo Matriz" },
  { nome: "Claudemir Severino", cargo: "Aux.", congregacao: "Templo Matriz" },
  { nome: "Dálton Almeida", cargo: "Aux.", congregacao: "Templo Matriz" },
  { nome: "Edjael Francisco", cargo: "Aux.", congregacao: "Templo Matriz" },
  { nome: "Jeremias Marculino", cargo: "Aux.", congregacao: "Templo Matriz" },
  { nome: "Jogle Uchôa", cargo: "Aux.", congregacao: "Templo Matriz" },
  { nome: "José Francisco Filho", cargo: "Aux.", congregacao: "Templo Matriz" },
  { nome: "Macksuel Gomes", cargo: "Aux.", congregacao: "Templo Matriz" },
  { nome: "Marllon Gomes", cargo: "Aux.", congregacao: "Templo Matriz" },
  { nome: "Tiago Veríssimo", cargo: "Aux.", congregacao: "Templo Matriz" },
  { nome: "Joalison Jorge", cargo: "Dc.", congregacao: "Templo Matriz" },
  { nome: "Murilo Henrique", cargo: "Dc.", congregacao: "Templo Matriz" },
  { nome: "Wermison Souza", cargo: "Dc.", congregacao: "Templo Matriz" },
  { nome: "Alexandre Silva", cargo: "Aux.", congregacao: "Monte Carmelo" },
  { nome: "Jesse Francisco", cargo: "Aux.", congregacao: "Monte Carmelo" },
  { nome: "Manoel Alves", cargo: "Aux.", congregacao: "Monte Carmelo" },
  { nome: "Matheus Alves", cargo: "Aux.", congregacao: "Monte Carmelo" },
  { nome: "Adelino Gomes", cargo: "Aux.", congregacao: "Monte das Oliveiras" },
  { nome: "Ivanildo Marculino", cargo: "Aux.", congregacao: "Monte das Oliveiras" },
  { nome: "Joabe Rodrigues", cargo: "Aux.", congregacao: "Monte das Oliveiras" },
  { nome: "Luciano Evaristo", cargo: "Aux.", congregacao: "Monte das Oliveiras" },
  { nome: "Edson Teixeira", cargo: "Aux.", congregacao: "Quinze" },
  { nome: "Gustavo Miguel", cargo: "Aux.", congregacao: "Quinze" },
  { nome: "Israel Soares", cargo: "Aux.", congregacao: "Quinze" },
  { nome: "João Paulino", cargo: "Aux.", congregacao: "Quinze" },
  { nome: "José Dionísio", cargo: "Aux.", congregacao: "Quinze" },
  { nome: "José Edvaldo", cargo: "Aux.", congregacao: "Quinze" },
  { nome: "José Farias", cargo: "Aux.", congregacao: "Quinze" },
  { nome: "José Mariano", cargo: "Aux.", congregacao: "Três Ladeiras" },
  { nome: "Arnaldo Bento", cargo: "Aux.", congregacao: "Vila Canaã" },
  { nome: "Moises Rodrigues", cargo: "Aux.", congregacao: "Engenho Vinagre" },
  { nome: "Roberto Joaquim", cargo: "Aux. Local.", congregacao: "Alto Planalto" },
  { nome: "Luciano Eronildo", cargo: "Aux. Local.", congregacao: "Av. Brasil" },
  { nome: "Sebastião Ribeiro", cargo: "Aux. Local.", congregacao: "Av. Brasil" },
  { nome: "Isaías Pereira", cargo: "Aux. Local.", congregacao: "Belo Oriente" },
  { nome: "José Otávio", cargo: "Aux. Local.", congregacao: "Belo Oriente" },
  { nome: "Vinícius José", cargo: "Aux. Local.", congregacao: "Belo Oriente" },
  { nome: "José Adriano", cargo: "Aux. Local.", congregacao: "Lot. Bom Jesus" },
  { nome: "Veronildo Manoel", cargo: "Aux. Local.", congregacao: "Lot. Bom Jesus" },
  { nome: "Alan Herculano", cargo: "Aux. Local.", congregacao: "Nova Canaã" },
  { nome: "Deyvison Felix", cargo: "Aux. Local.", congregacao: "Nova Canaã" },
  { nome: "Joseilton Alves", cargo: "Aux. Local.", congregacao: "Nova Canaã" },
  { nome: "Kelvis Lopes", cargo: "Aux. Local.", congregacao: "Nova Canaã" },
  { nome: "Vanduir josé", cargo: "Aux. Local.", congregacao: "Nova Canaã" },
  { nome: "Cristiano Antônio", cargo: "Aux. Local.", congregacao: "Chã do Conselho 01" },
  { nome: "Daniel Felipe", cargo: "Aux. Local.", congregacao: "Chã do Conselho 01" },
  { nome: "José Valter", cargo: "Aux. Local.", congregacao: "Chã do Conselho 01" },
  { nome: "Luiz Pereira", cargo: "Aux. Local.", congregacao: "Chã do Conselho 01" },
  { nome: "Anderson Ferreira", cargo: "Aux. Local.", congregacao: "Itaboraí" },
  { nome: "José Jeverson", cargo: "Aux. Local.", congregacao: "Itaboraí" },
  { nome: "Miqueias Tavares", cargo: "Aux. Local.", congregacao: "Itapipiré" },
  { nome: "Raldny Antonio", cargo: "Aux. Local.", congregacao: "Itapipiré" },
  { nome: "Adriano Albuquerque", cargo: "Aux. Local.", congregacao: "Jardim Nova Esperança" },
  { nome: "André Francisco", cargo: "Aux. Local.", congregacao: "Jardim Nova Esperança" },
  { nome: "Rafael Tenório", cargo: "Aux. Local.", congregacao: "Lot. Fontes de Aldeia" },
  { nome: "Allyson Nyerton", cargo: "Aux. Local.", congregacao: "Templo Matriz" },
  { nome: "Daniel Lira", cargo: "Aux. Local.", congregacao: "Templo Matriz" },
  { nome: "Edvan José", cargo: "Aux. Local.", congregacao: "Templo Matriz" },
  { nome: "Everaldo Alves", cargo: "Aux. Local.", congregacao: "Templo Matriz" },
  { nome: "José Marculino", cargo: "Aux. Local.", congregacao: "Templo Matriz" },
  { nome: "Junark Marculino", cargo: "Aux. Local.", congregacao: "Templo Matriz" },
  { nome: "Lucas França", cargo: "Aux. Local.", congregacao: "Templo Matriz" },
  { nome: "Mario Fernandes", cargo: "Aux. Local.", congregacao: "Templo Matriz" },
  { nome: "Severino Alexandre", cargo: "Aux. Local.", congregacao: "Templo Matriz" },
  { nome: "Washington Souza", cargo: "Aux. Local.", congregacao: "Templo Matriz" },
  { nome: "Israel Antonio", cargo: "Aux. Local.", congregacao: "Monte Carmelo" },
  { nome: "Josenildo José", cargo: "Aux. Local.", congregacao: "Monte Carmelo" },
  { nome: "Miguel Mendes", cargo: "Aux. Local.", congregacao: "Monte Carmelo" },
  { nome: "Pedro Henrique", cargo: "Aux. Local.", congregacao: "Monte Carmelo" },
  { nome: "Mario Filho", cargo: "Aux. Local.", congregacao: "Monte das Oliveiras" },
  { nome: "Ricardo José", cargo: "Aux. Local.", congregacao: "Monte das Oliveiras" },
  { nome: "Gilmario Terto", cargo: "Aux. Local.", congregacao: "Penedinho" },
  { nome: "Miguel Cândido", cargo: "Aux. Local.", congregacao: "Quinze" },
  { nome: "Carlos Roberto", cargo: "Aux. Local.", congregacao: "Três Ladeiras" },
  { nome: "Lenildo Freitas", cargo: "Aux. Local.", congregacao: "Três Ladeiras" },
  { nome: "José Bento", cargo: "Aux. Local.", congregacao: "Vila Canaã" },
];

const EVENTOS_PADRAO: Evento[] = [
  { id: "1", data: "2026-04-13", descricao: "Círculo de Oração - Quinze/Canaã", cc: "CO", congregacao: "-" },
  { id: "2", data: "2026-04-14", descricao: "Círculo de Oração - Monte Carmelo", cc: "CO", congregacao: "-" },
  { id: "3", data: "2026-04-15", descricao: "Círculo de Oração - Itapipiré", cc: "CO", congregacao: "-" },
  { id: "4", data: "2026-04-16", descricao: "Círculo de Oração - Jd. Nova Esperança", cc: "CO", congregacao: "-" },
  { id: "5", data: "2026-04-17", descricao: "Círculo de Oração - Monte das Oliveiras", cc: "CO", congregacao: "-" },
];

const ESCALA_LOCAL_PADRAO: EscalaLocalItem[] = [
  // Círculo de Oração
  { categoria: "📖 CÍRCULO DE ORAÇÃO (C.O.)", data: "13/04/2026", local: "Quinze", codigo: "34", escalados: ["Pr. Severino Guilhermino", "Dc. Benjamin Alexandre"] },
  { categoria: "📖 CÍRCULO DE ORAÇÃO (C.O.)", data: "13/04/2026", local: "Canaã", codigo: "34", escalados: ["Pr. Severino Guilhermino", "Dc. Manuel Elias"] },
  { categoria: "📖 CÍRCULO DE ORAÇÃO (C.O.)", data: "14/04/2026", local: "Monte Carmelo", codigo: "34", escalados: ["Pr. Severino Guilhermino", "Dc. Benjamin Alexandre"] },
  { categoria: "📖 CÍRCULO DE ORAÇÃO (C.O.)", data: "14/04/2026", local: "Chã do Conselho", codigo: "34", escalados: ["Pr. Severino Guilhermino", "Aux. Valmir Gervásio"] },
  { categoria: "📖 CÍRCULO DE ORAÇÃO (C.O.)", data: "15/04/2026", local: "Itapipiré", codigo: "34", escalados: ["Pr. Severino Guilhermino", "Aux. Local. André Francisco"] },
  { categoria: "📖 CÍRCULO DE ORAÇÃO (C.O.)", data: "16/04/2026", local: "Jardim Nova Esperança", codigo: "34", escalados: ["Pr. Severino Guilhermino", "Dc. Benjamin Alexandre"] },
  { categoria: "📖 CÍRCULO DE ORAÇÃO (C.O.)", data: "17/04/2026", local: "Monte das Oliveiras", codigo: "34", escalados: ["Pr. Severino Guilhermino", "Pb. Antônio Alexandre"] },
  // Pontos de Pregação
  { categoria: "📍 PONTOS DE PREGAÇÃO (PP)", data: "15/04/2026", local: "Miritibi (PP)", codigo: "61", escalados: ["Dc. Dorgival Gervásio", "Dc. Samuel Amaro", "Aux. Paulo Cândido", "Aux. Local. José Valter"] },
  { categoria: "📍 PONTOS DE PREGAÇÃO (PP)", data: "16/04/2026", local: "Belo Oriente (Jeová Sama) (PP)", codigo: "61", escalados: ["Pb. Ednaldo Antônio", "Dc. Daniel Domingos", "Aux. Jefferson Balbino", "Aux. Local. Gilmario Terto"] },
  // Portaria
  { categoria: "🚪 ESCALA SEMANAL - PORTARIA", data: "13/04/2026", local: "Templo Matriz", codigo: "PP", escalados: ["Dc. Severino José", "Aux. Local. Washington Souza", "Aux. Local. Severino Alexandre"] },
  { categoria: "🚪 ESCALA SEMANAL - PORTARIA", data: "14/04/2026", local: "Templo Matriz", codigo: "PP", escalados: ["Aux. Jeremias Marculino", "Aux. Edinael Eliel", "Aux. Local. Joseilton Alves"] },
  { categoria: "🚪 ESCALA SEMANAL - PORTARIA", data: "15/04/2026", local: "Templo Matriz", codigo: "PP", escalados: ["Dc. Severino José", "Aux. Local. Daniel Lira", "Aux. Local. Israel Antonio"] },
  { categoria: "🚪 ESCALA SEMANAL - PORTARIA", data: "15/04/2026", local: "Chã do Conselho 2", codigo: "PP", escalados: ["Dc. Kleitonlee Marcionilo", "Aux. Bruno Bezerra", "Aux. Local. Cristiano Antônio"] },
  { categoria: "🚪 ESCALA SEMANAL - PORTARIA", data: "19/04/2026", local: "Templo Matriz", codigo: "PP", escalados: ["Dc. Severino José", "Aux. Jeremias Marculino", "Aux. Local. Israel Antonio"] },
];

export default function App() {
  const [activeTab, setActiveTab] = useState("escala-oficial");
  const [dataInicio, setDataInicio] = useState(format(startOfWeek(new Date(), { weekStartsOn: 1 }), "yyyy-MM-dd"));
  const [isConfigured, setIsConfigured] = useState<boolean | null>(null);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  // States for Duplicate Check Modal
  const [duplicateModal, setDuplicateModal] = useState<{
    isOpen: boolean;
    worker: string;
    congregacao: string;
    diaLabel: string;
    targetTab: "oficial" | "local";
    targetDayId: string;
    targetRowIndex: number;
    targetEscaladoIndex: number;
  }>({
    isOpen: false,
    worker: "",
    congregacao: "",
    diaLabel: "",
    targetTab: "oficial",
    targetDayId: "",
    targetRowIndex: 0,
    targetEscaladoIndex: 0
  });
  
  // Data State
  const [obreiros, setObreiros] = useState<Obreiro[]>(OBREIROS_PADRAO);
  const [congregacoes, setCongregacoes] = useState<string[]>(CONGREGACOES_PADRAO);
  const [escalaOficial, setEscalaOficial] = useState<EscalaOficialData>({});
  const [escalaLocal, setEscalaLocal] = useState<EscalaLocalItem[]>(ESCALA_LOCAL_PADRAO);
  const [eventos, setEventos] = useState<Evento[]>(EVENTOS_PADRAO);
  const [tiposCulto, setTiposCulto] = useState<TipoCulto[]>([
    { nome: "Santa Ceia", codigo: "03" },
    { nome: "Administrativo", codigo: "05" },
    { nome: "Culto Jovem", codigo: "71" }
  ]);
  const [regrasCulto, setRegrasCulto] = useState<RegraCulto[]>([]);

  // Editing States
  const [editingObreiro, setEditingObreiro] = useState<number | null>(null);
  const [editingEvento, setEditingEvento] = useState<number | null>(null);
  const [editingCongregacao, setEditingCongregacao] = useState<number | null>(null);
  const [editingTipoCulto, setEditingTipoCulto] = useState<number | null>(null);
  const [editingRegra, setEditingRegra] = useState<number | null>(null);

  // Fetch data on mount
  useEffect(() => {
    checkStatus();
    loadData();
  }, [dataInicio]); // Reload when date changes to filter correctly

  const checkStatus = async () => {
    try {
      const res = await fetch("/api/status");
      const data: any = await res.json();
      setIsConfigured(data.configured);
    } catch {
      setIsConfigured(false);
    }
  };

  const getWeekOfMonth = (date: Date) => {
    const firstDay = new Date(date.getFullYear(), date.getMonth(), 1);
    const day = date.getDate();
    return Math.ceil((day + firstDay.getDay()) / 7);
  };

  const loadData = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/sync");
      
      // If server says not configured (400), we just use defaults silently
      if (res.status === 400) {
        setObreiros(OBREIROS_PADRAO);
        setCongregacoes(CONGREGACOES_PADRAO);
        setIsConfigured(false);
        return;
      }

      if (!res.ok) {
        const errJson = await res.json().catch(() => ({}));
        throw new Error(errJson.error || `Erro HTTP: ${res.status}`);
      }

      const data: any = await res.json();
      setIsConfigured(true);
      
      const sheetObreiros = data.obreiros.map((row: any) => ({ 
        nome: row[0] || "", 
        congregacao: row[1] || "", 
        cargo: row[2] || "Aux." 
      }));
      
      if (sheetObreiros.length > 0) {
        setObreiros(sheetObreiros);
      } else {
        setObreiros(OBREIROS_PADRAO);
      }

      const sheetEventos = data.eventos?.map((row: any) => ({
        id: row[0] || Math.random().toString(36).substr(2, 9),
        data: row[1] || "",
        descricao: row[2] || "",
        cc: row[3] || "",
        congregacao: row[4] || ""
      })) || [];
      if (sheetEventos.length > 0) setEventos(sheetEventos);
      else setEventos(EVENTOS_PADRAO);

      const sheetLocal = data.escalaLocal?.map((row: any) => ({
        categoria: row[0] || "",
        data: row[1] || "",
        local: row[2] || "",
        codigo: row[3] || "",
        escalados: row[4]?.split(",")?.map((s: string) => s.trim()) || []
      })) || [];
      if (sheetLocal.length > 0) setEscalaLocal(sheetLocal);
      else setEscalaLocal(ESCALA_LOCAL_PADRAO);

      const sheetCongregacoes = data.congregacoes.map((row: any) => row[0]);
      if (sheetCongregacoes.length > 0) {
        setCongregacoes(sheetCongregacoes);
      } else {
        setCongregacoes(CONGREGACOES_PADRAO);
      }

      const sheetTipos = data.tiposCulto?.map((row: any) => ({
        nome: row[0] || "",
        codigo: row[1] || ""
      })) || [];
      if (sheetTipos.length > 0) setTiposCulto(sheetTipos);

      const sheetRegras = data.regrasCulto?.map((row: any) => ({
        congregacao: row[0] || "",
        dia: row[1] || "",
        regraSemana: [row[2], row[3], row[4], row[5], row[6]]
      })) || [];
      if (sheetRegras.length > 0) setRegrasCulto(sheetRegras);

      const oficial: EscalaOficialData = {};
      data.escalaOficial.forEach((row: any) => {
        const [dw, dia, cong, cod, esc] = row;
        if (dw === dataInicio) {
          if (!oficial[dia]) oficial[dia] = [];
          oficial[dia].push({ congregacao: cong, codigo: cod, escalados: esc?.split(",")?.map((s: string) => s.trim()) || [] });
        }
      });

      // If official is empty for current week, initialize with fixed congregations
      if (Object.keys(oficial).length === 0) {
        DIAS_SEMANA_OFICIAL.forEach(dia => {
          oficial[dia.id] = dia.filtros.map(cong => ({
            congregacao: cong,
            codigo: "04", // Default code (Doutrina)
            escalados: []
          }));
        });
      }
      setEscalaOficial(oficial);

      setEscalaLocal(data.escalaLocal.map((row: any) => ({
        categoria: row[1],
        data: row[2],
        local: row[3],
        codigo: row[4],
        escalados: row[5]?.split(",") || []
      })));
      
      setEventos(data.eventos.map((row: any) => ({
        id: Math.random().toString(36).substr(2, 9),
        data: row[0],
        descricao: row[1],
        cc: row[2],
        congregacao: row[3]
      })));

    } catch (err: any) {
      console.error(err);
      // Only alert on real errors, not just unconfigured
      if (isConfigured !== false) {
        alert("Erro ao carregar dados: " + err.message);
      }
    } finally {
      setLoading(false);
    }
  };

  const saveData = async () => {
    if (!isConfigured) return alert("Configure as credenciais do Google Sheets no painel de Segredos primeiro.");
    setSaving(true);
    try {
      // Prepare sheets data
      const obreirosRows = obreiros.map(o => [o.nome, o.cargo, o.congregacao]);
      const congRows = congregacoes.map(c => [c]);
      
      const oficialRows: any[] = [];
      (Object.entries(escalaOficial) as [string, EscalaItem[]][]).forEach(([dia, items]) => {
        items.forEach(item => {
          oficialRows.push([dataInicio, dia, item.congregacao, item.codigo, item.escalados.join(",")]);
        });
      });

      const localRows = escalaLocal.map(l => [dataInicio, l.categoria, l.data, l.local, l.codigo, l.escalados.join(",")]);
      const eventoRows = eventos.map(e => [e.data, e.descricao, e.cc, e.congregacao]);
      const tipoRows = tiposCulto.map(t => [t.nome, t.codigo]);
      const regraRows = regrasCulto.map(r => [r.congregacao, r.dia, ...r.regraSemana]);

      // Batch save
      await saveSheet("Obreiros!A:C", obreirosRows);
      await saveSheet("Congregacoes!A:A", congRows);
      await saveSheet("EscalaOficial!A:E", oficialRows);
      await saveSheet("EscalaLocal!A:G", localRows);
      await saveSheet("Eventos!A:D", eventoRows);
      await saveSheet("TiposCulto!A:B", tipoRows);
      await saveSheet("RegrasCulto!A:G", regraRows);

      alert("Dados salvos com sucesso no Google Planilhas!");
    } catch (err) {
      alert("Erro ao salvar dados");
    } finally {
      setSaving(false);
    }
  };

  const saveSheet = async (range: string, values: any[][]) => {
    const res = await fetch("/api/sheets/update", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ range, values })
    });
    if (!res.ok) throw new Error("Update failed");
  };

  // Helper for dynamic dates
  const getDiaData = (diaId: string) => {
    const start = parseISO(dataInicio);
    const offsetMap: { [key: string]: number } = {
      segunda: 0, terca: 1, quarta: 2, quintaManha: 3, quintaTarde: 3, quintaNoite: 3,
      sexta: 4, sabado: 5, domingoManha: 6, domingoNoite: 6
    };
    return format(addDays(start, offsetMap[diaId] || 0), "dd/MM/yyyy");
  };

  const getWeekRange = useMemo(() => {
    const start = parseISO(dataInicio);
    const end = addDays(start, 6);
    return { start, end };
  }, [dataInicio]);

  const eventosDaSemana = useMemo(() => {
    return eventos.filter(ev => {
      try {
        // Handle d/M/yyyy format from Sheets
        const [d, m, y] = ev.data.split('/').map(Number);
        if(!y) return false;
        const evDate = new Date(y, m - 1, d);
        return isWithinInterval(evDate, getWeekRange);
      } catch { return false; }
    });
  }, [eventos, getWeekRange]);

  const getDiaStr = (diaId: string) => {
    const offset: { [key: string]: number } = { 
      segunda: 0, terca: 1, quarta: 2, quintaManha: 3, quintaTarde: 3, quintaNoite: 3, 
      sexta: 4, sabado: 5, domingoManha: 6, domingoNoite: 6 
    };
    return format(addDays(getWeekRange.start, offset[diaId] || 0), "dd/MM", { locale: ptBR });
  };

  const gerarObreirosQuarta = () => {
    const hierarquia: { [key: string]: number } = { "Pr.": 1, "Pb.": 2, "Dc.": 3, "Aux.": 4, "Aux. Local.": 5 };
    const newEscala = { ...escalaOficial };
    if (!newEscala["quarta"]) {
      alert("Aba de Quarta-feira não possui congregações definidas.");
      return;
    }

    const obreirosUsados = new Set();
    // Coleta obreiros já escalados na quarta
    newEscala["quarta"].forEach(item => {
      item.escalados.forEach(e => { if(e) obreirosUsados.add(e); });
    });

    // Filtra disponíveis e ordena por hierarquia
    const disponiveis = obreiros
      .filter(o => !obreirosUsados.has(`${o.cargo} ${o.nome}`))
      .sort((a,b) => (hierarquia[a.cargo] || 99) - (hierarquia[b.cargo] || 99));

    let idx = 0;
    const itemsQuarta = [...newEscala["quarta"]];
    itemsQuarta.forEach((item, iIdx) => {
      // Se a primeira vaga estiver vazia, preenche
      if (!item.escalados[0] && idx < disponiveis.length) {
        itemsQuarta[iIdx].escalados[0] = `${disponiveis[idx].cargo} ${disponiveis[idx].nome}`;
        idx++;
      }
    });

    newEscala["quarta"] = itemsQuarta;
    setEscalaOficial(newEscala);
    alert(`Obreiros gerados automaticamente para ${idx} congregações na Quarta-Feira!`);
  };

  const aplicarRegrasGerais = () => {
    const curDate = parseISO(dataInicio);
    const weekNum = getWeekOfMonth(curDate);
    const newOficial = { ...escalaOficial };
    
    Object.keys(newOficial).forEach(diaId => {
      newOficial[diaId] = newOficial[diaId].map(item => {
        const regra = regrasCulto.find(r => r.congregacao === item.congregacao && r.dia === diaId);
        if (regra) {
          const ruleCode = regra.regraSemana[weekNum - 1];
          if (ruleCode) {
            // Find code for the rule name
            const worshipType = tiposCulto.find(t => t.nome === ruleCode);
            return { ...item, codigo: worshipType ? worshipType.codigo : item.codigo };
          }
        }
        return item;
      });
    });
    
    setEscalaOficial(newOficial);
    alert("Regras de culto aplicadas com sucesso para a " + weekNum + "ª semana!");
  };

  const handleDeleteObreiro = (index: number) => {
    if (confirm("Deseja realmente excluir este obreiro?")) {
      const newObreiros = [...obreiros];
      newObreiros.splice(index, 1);
      setObreiros(newObreiros);
    }
  };

  const handleDeleteEvento = (id: string) => {
    if (confirm("Deseja realmente excluir este evento?")) {
      setEventos(prev => prev.filter(e => e.id !== id));
    }
  };

  const handleDeleteRegra = (index: number) => {
    if (confirm("Deseja excluir esta regra?")) {
      const newRegras = [...regrasCulto];
      newRegras.splice(index, 1);
      setRegrasCulto(newRegras);
    }
  };

  const handleEditObreiro = (index: number) => {
    const ob = obreiros[index];
    const nome = prompt("Novo nome:", ob.nome);
    const cargo = prompt("Novo cargo (Pr./Pb./Dc./Aux./Aux. Local.):", ob.cargo);
    const cong = prompt("Nova congregação:", ob.congregacao);
    if (nome && cargo && cong) {
      const newObreiros = [...obreiros];
      newObreiros[index] = { nome, cargo, congregacao: cong };
      setObreiros(newObreiros);
    }
  };

  const handleEditEvento = (index: number) => {
    const ev = eventos[index];
    const desc = prompt("Nova descrição:", ev.descricao);
    const data = prompt("Nova data (AAAA-MM-DD):", ev.data);
    const cc = prompt("Novo Código:", ev.cc);
    const cong = prompt("Nova congregação:", ev.congregacao);
    if (desc && data && cong) {
      const newEvs = [...eventos];
      newEvs[index] = { ...ev, descricao: desc, data, cc: cc || "", congregacao: cong };
      setEventos(newEvs);
    }
  };

  const checkDuplicateWorker = (
    worker: string, 
    dayId: string, 
    currentRowIndex: number, 
    currentEscaladoIndex: number,
    tab: "oficial" | "local"
  ) => {
    if (!worker) return;

    if (tab === "oficial") {
      const dayScale = escalaOficial[dayId] || [];
      for (let rIdx = 0; rIdx < dayScale.length; rIdx++) {
        const row = dayScale[rIdx];
        for (let eIdx = 0; eIdx < row.escalados.length; eIdx++) {
          // Skip the current being edited
          if (rIdx === currentRowIndex && eIdx === currentEscaladoIndex) continue;

          if (row.escalados[eIdx] === worker) {
            setDuplicateModal({
              isOpen: true,
              worker,
              congregacao: row.congregacao,
              diaLabel: DIAS_SEMANA_OFICIAL.find(d => d.id === dayId)?.label || "este dia",
              targetTab: "oficial",
              targetDayId: dayId,
              targetRowIndex: currentRowIndex,
              targetEscaladoIndex: currentEscaladoIndex
            });
            return;
          }
        }
      }
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="min-h-screen bg-[#eef3f9] text-[#0a2a4a] font-sans print:bg-white print:p-0">
      {/* Sticky Menu - Floating at top */}
      <div className="menu-fixo no-print">
         <div className="abas">
            <button onClick={() => setActiveTab("escala-oficial")} className={`aba-btn ${activeTab === "escala-oficial" ? "ativa" : ""}`}>
               📆 Escala Oficial
            </button>
            <button onClick={() => setActiveTab("escala-local")} className={`aba-btn ${activeTab === "escala-local" ? "ativa" : ""}`}>
               📆 Escala Local
            </button>
            <button onClick={() => setActiveTab("obreiros")} className={`aba-btn ${activeTab === "obreiros" ? "ativa" : ""}`}>
               👥 Obreiros
            </button>
            <button onClick={() => setActiveTab("calendario")} className={`aba-btn ${activeTab === "calendario" ? "ativa" : ""}`}>
               📅 Calendário
            </button>
            <button onClick={() => setActiveTab("config")} className={`aba-btn ${activeTab === "config" ? "ativa" : ""}`}>
               ⚙️ Config
            </button>
         </div>
      </div>

      <div className="container-app p-4 md:p-8 mt-5">

         {/* Header Logo Row - Exact HTML Match (Conditioned) */}
         {(activeTab === "escala-oficial" || activeTab === "escala-local") && (
            <div className="header-iead border-b-2 border-[#b8d0e8] pb-4 mb-5">
               <div className="flex items-center justify-between gap-4 max-w-6xl mx-auto">
                   <div className="flex flex-col gap-2 flex-1">
                       <div className="flex flex-col leading-tight">
                           <span className="font-bold text-[#0e3d6e] text-lg">Pr. Ailton José Alves</span>
                           <span className="text-[#1a5fa0] text-sm italic">Presidente da IEADPE</span>
                       </div>
                       <div className="flex flex-col leading-tight mt-1">
                           <span className="font-bold text-[#0e3d6e] text-lg">Pr. Severino Guilhermino</span>
                           <span className="text-[#1a5fa0] text-sm italic">Pastor da Filial</span>
                       </div>
                   </div>
                   
                   <div className="flex flex-col items-center">
                       <img 
                         src="https://static.ieadpe.org.br/ieadpe_logo_colorido_pequeno.png" 
                         alt="Logo IEADPE" 
                         className="w-24 h-24 object-contain" 
                         referrerPolicy="no-referrer"
                       />
                   </div>
   
                   <div className="flex flex-col items-end flex-1 text-right">
                       <span className="text-4xl font-black text-[#0e3d6e] tracking-[3px] leading-none">IEADPE</span>
                       <span className="text-base font-bold text-[#1a5fa0] tracking-wider">FILIAL ARAÇOIABA</span>
                   </div>
               </div>
            </div>
         )}

         {/* Codigos Panel - Shown only in Scales */}
         {(activeTab === "escala-oficial" || activeTab === "escala-local") && (
           <div className="codigos-painel-topo">
              <h3 className="no-print">📋 CÓDIGOS DOS TRABALHOS</h3>
              <div className="grid-codigos static-grid">
                 {CODIGOS_TRABALHO.map((cod, i) => (
                   <div key={i} className="cod-item">
                      {cod}
                   </div>
                 ))}
              </div>
           </div>
         )}

         {/* Data Semana Selector - Styled like HTML */}
         <div className="flex flex-wrap items-center justify-center gap-4 py-4 mb-5 bg-[#e6f0fa] rounded-full mx-auto max-w-fit px-8 border border-[#a8c8e8] no-print">
            <label className="font-bold text-[#0d3d7a]">📅 Semana de (segunda-feira):</label>
            <input 
              type="date" 
              value={dataInicio}
              onChange={(e) => setDataInicio(e.target.value)}
              className="bg-white border border-[#a8c8e8] rounded-full px-4 py-1.5 font-mono text-sm focus:outline-none"
            />
            <button 
              onClick={loadData}
              className="bg-[#0d4a8a] text-white px-6 py-1.5 rounded-full text-sm font-bold flex items-center gap-2 hover:bg-[#1a5fa0] transition-colors"
            >
              <RefreshCw size={14} className={loading ? "animate-spin" : ""} /> Atualizar Datas
            </button>
         </div>
      </div>

      <main className="max-w-full mx-auto">
        {/* DUPLICATE MODAL - Exact Request Match */}
        <AnimatePresence>
          {duplicateModal.isOpen && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 z-[9999] flex items-center justify-center p-4 backdrop-blur-sm"
            >
              <motion.div 
                initial={{ scale: 0.9, y: 20 }}
                animate={{ scale: 1, y: 0 }}
                className="bg-white rounded-2xl p-8 max-w-md w-full shadow-2xl border-t-[5px] border-[#e05c2a] text-center"
              >
                <div className="text-5xl mb-4">⚠️</div>
                <h3 className="text-[#b83a10] font-black text-xl mb-3">Obreiro já escalado neste dia!</h3>
                <p className="text-[#333] font-bold text-lg mb-2">{duplicateModal.worker}</p>
                <div className="bg-[#fff3f0] p-4 rounded-xl border-l-4 border-[#e05c2a] mb-6 inline-block text-left w-full">
                  <p className="text-[#555] text-sm">
                    Já está escalado em <strong>{duplicateModal.congregacao}</strong> neste mesmo dia ({duplicateModal.diaLabel}).
                  </p>
                </div>
                
                <div className="flex gap-3 justify-center">
                   <button 
                    onClick={() => setDuplicateModal(prev => ({ ...prev, isOpen: false }))}
                    className="bg-[#0d4a8a] text-white px-6 py-2 rounded-full font-bold text-sm"
                   >
                     ✅ Manter assim mesmo
                   </button>
                   <button 
                    onClick={() => {
                      const newEscala = { ...escalaOficial };
                      newEscala[duplicateModal.targetDayId][duplicateModal.targetRowIndex].escalados[duplicateModal.targetEscaladoIndex] = "";
                      setEscalaOficial(newEscala);
                      setDuplicateModal(prev => ({ ...prev, isOpen: false }));
                    }}
                    className="bg-[#e05c2a] text-white px-6 py-2 rounded-full font-bold text-sm"
                   >
                     ❌ Remover desta vaga
                   </button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="flex justify-between items-center mb-6 no-print">
            <h2 className="text-2xl font-black text-[#0d4a8a] uppercase tracking-tighter">
              {activeTab.replace("-", " ")}
            </h2>
            <div className="flex gap-2">
                 <button onClick={handlePrint} className="bg-blue-600 text-white p-2 rounded-full hover:bg-blue-700 transition-colors shadow-lg">
                    <Printer size={20} />
                 </button>
                 {activeTab === "escala-oficial" && (
                    <button onClick={gerarObreirosQuarta} className="bg-orange-600 text-white px-4 py-1.5 rounded-full text-sm font-black uppercase">
                       🎲 Gerar Quarta
                    </button>
                 )}
            </div>
          </div>
          {activeTab === "escala-oficial" && (
            <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
              
              {/* Eventos da Semana (Otimizado) */}
              {eventosDaSemana.length > 0 && (
                <div className="bg-orange-50 border-2 border-orange-100 rounded-xl p-4 print:bg-white print:border-slate-300 print:rounded-none">
                  <h3 className="text-orange-800 font-black text-xs uppercase mb-3 flex items-center gap-2 print:text-black">
                     🗓️ EVENTOS DESTA SEMANA
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-2">
                    {eventosDaSemana.map((ev, idx) => (
                      <div key={idx} className="text-[10px] bg-white p-2 rounded border border-orange-50 shadow-sm flex flex-col print:shadow-none print:border-none">
                        <span className="font-bold text-orange-900 print:text-black">{ev.data.split('/')[0]}/{ev.data.split('/')[1]} - {ev.descricao}</span>
                        <span className="text-slate-500 italic">{ev.congregacao}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="grid grid-cols-1 gap-6 print:block print:space-y-6">
                {DIAS_SEMANA_OFICIAL.map((dia) => (
                  <div key={dia.id} className="day-section overflow-hidden border border-[#c5daf0] shadow-sm print:shadow-none print:border-gray-300">
                    <div className="day-title py-2 px-4 flex justify-between items-center print:border-b">
                      <h3 className="font-bold text-xs uppercase">{dia.label}</h3>
                      <span className="day-date font-mono text-[10px] text-white/80">{getDiaStr(dia.id)}</span>
                    </div>
                    
                    <div className="p-0">
                      <table className="w-full text-[10px] text-left">
                        <thead>
                          <tr className="bg-[#e6f0fa] print:bg-white border-b border-[#c5daf0]">
                            <th className="p-2 font-bold text-[#0d3d7a] w-1/3">CONGREGAÇÃO</th>
                            <th className="p-1 font-bold text-[#0d3d7a] w-8 text-center uppercase">Có d</th>
                            <th className="p-2 font-bold text-[#0d3d7a]">ESCALADOS</th>
                            <th className="p-1 w-6 no-print"></th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-[#c5d8ef]">
                          {(escalaOficial[dia.id] || []).map((item, idx) => (
                            <tr key={idx} className="group even:bg-slate-50/50">
                              <td className="p-1 cong-nome">
                                <select 
                                  value={item.congregacao}
                                  onChange={(e) => {
                                    const newEscala = { ...escalaOficial };
                                    newEscala[dia.id][idx].congregacao = e.target.value;
                                    setEscalaOficial(newEscala);
                                  }}
                                  className="w-full bg-transparent border-none focus:ring-0 text-[10px] font-bold p-1 cursor-pointer"
                                >
                                  {congregacoes.map(c => <option key={c} value={c}>{c}</option>)}
                                </select>
                              </td>
                              <td className="p-1 text-center font-bold text-[#1a5fa0] bg-[#fff9e8]">
                                <input 
                                  type="text"
                                  value={item.codigo}
                                  onChange={(e) => {
                                    const newEscala = { ...escalaOficial };
                                    newEscala[dia.id][idx].codigo = e.target.value;
                                    setEscalaOficial(newEscala);
                                  }}
                                  className="w-full bg-transparent border-none text-center focus:ring-0 text-[10px] p-0 font-bold"
                                />
                              </td>
                              <td className="p-1 px-2">
                                <div className="flex gap-1 flex-nowrap overflow-x-auto">
                                  {item.escalados.map((esc, eIdx) => (
                                    <select
                                      key={eIdx}
                                      value={esc}
                                      onChange={(e) => {
                                        const newValue = e.target.value;
                                        const newEscala = { ...escalaOficial };
                                        newEscala[dia.id][idx].escalados[eIdx] = newValue;
                                        setEscalaOficial(newEscala);
                                        
                                        // Check for duplicates
                                        checkDuplicateWorker(newValue, dia.id, idx, eIdx, "oficial");
                                      }}
                                      className="flex-1 min-w-[110px] bg-[#fffef7] border border-[#a8c8e8] rounded-md focus:ring-1 focus:ring-blue-500 text-[10px] font-semibold h-7 px-1 cursor-pointer"
                                    >
                                      <option value="">─ Selecione ─</option>
                                      {obreiros.map(o => (
                                        <option key={`${o.cargo} ${o.nome}`} value={`${o.cargo} ${o.nome}`}>
                                          {o.cargo} {o.nome}
                                        </option>
                                      ))}
                                    </select>
                                  ))}
                                </div>
                              </td>
                              <td className="p-1 text-center no-print">
                                <button 
                                  onClick={() => {
                                    const newEscala = { ...escalaOficial };
                                    newEscala[dia.id].splice(idx, 1);
                                    setEscalaOficial(newEscala);
                                  }}
                                  className="text-red-300 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"
                                >
                                  <Trash2 size={12} />
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                    
                    <button 
                      onClick={() => {
                        const newEscala = { ...escalaOficial };
                        if(!newEscala[dia.id]) newEscala[dia.id] = [];
                        newEscala[dia.id].push({ congregacao: congregacoes[0] || "Templo Matriz", codigo: "15", escalados: ["", "", ""] });
                        setEscalaOficial(newEscala);
                      }}
                      className="no-print w-full py-2 bg-[#f8fafc] hover:bg-blue-50 text-[#0d4a8a] text-[9px] font-bold uppercase border-t border-[#c5daf0]"
                    >
                      + ADICIONAR CONGREGAÇÃO
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === "escala-local" && (
            <div className="space-y-10 animate-in fade-in duration-500">
               {/* Seção C.O. */}
               <div className="day-section">
                  <div className="day-title">📖 CÍRCULO DE ORAÇÃO (C.O.)</div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4">
                    {["SEGUNDA", "TERÇA", "QUARTA", "QUINTA", "SEXTA"].map(dw => {
                      const coItems = escalaLocal.filter(l => l.categoria === "C.O" && l.data.toUpperCase().includes(dw));
                      if (coItems.length === 0) return null;
                      return (
                        <div key={dw} className="bg-white border border-[#c5daf0] rounded-xl overflow-hidden shadow-sm">
                           <div className="bg-[#e6f0fa] py-2 px-4 text-center font-bold text-[#0d3d7a] text-xs tracking-widest border-b border-[#c5daf0]">{dw}-FEIRA</div>
                           <table className="w-full text-xs">
                              <thead><tr className="bg-[#f0f6ff]">
                                <th className="p-2 border-b border-[#c5daf0] text-[#0d3d7a]">LOCAL</th>
                                <th className="p-2 border-b border-[#c5daf0] border-x text-center w-10 text-[#0d3d7a]">CÓD</th>
                                <th className="p-2 border-b border-[#c5daf0] text-[#0d3d7a]">ESCALADOS</th>
                              </tr></thead>
                              <tbody className="divide-y divide-[#c5d8ef]">
                                 {coItems.map((l, i) => (
                                   <tr key={i}>
                                      <td className="p-2 font-bold text-[#0d3d7a] bg-slate-50/50">{l.local}</td>
                                      <td className="p-2 text-center font-bold text-[#1a5fa0] bg-[#fff9e8] border-x border-[#c5daf0]">{l.codigo || "34"}</td>
                                      <td className="p-1">
                                         <div className="flex gap-1 flex-nowrap overflow-x-auto">
                                            {l.escalados.map((esc, eIdx) => (
                                              <select
                                                key={eIdx}
                                                value={esc}
                                                onChange={(e) => {
                                                  const newLocal = [...escalaLocal];
                                                  const itemIdx = escalaLocal.indexOf(l);
                                                  newLocal[itemIdx].escalados[eIdx] = e.target.value;
                                                  setEscalaLocal(newLocal);
                                                }}
                                                className="flex-1 min-w-[80px] bg-[#fffef7] border border-[#a8c8e8] rounded-md p-0.5 text-[10px] font-semibold h-6 cursor-pointer"
                                              >
                                                <option value="">─</option>
                                                {obreiros.map(o => <option key={`${o.cargo} ${o.nome}`} value={`${o.cargo} ${o.nome}`}>{o.cargo} {o.nome}</option>)}
                                              </select>
                                            ))}
                                         </div>
                                      </td>
                                   </tr>
                                 ))}
                              </tbody>
                           </table>
                        </div>
                      );
                    })}
                  </div>
               </div>

               {/* Seção Portaria / PP */}
               <div className="day-section">
                  <div className="day-title">🚪 PORTARIA / PP / EVENTOS</div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 p-6">
                     <div className="bg-white border border-[#c5daf0] rounded-xl overflow-hidden shadow-sm">
                        <div className="bg-[#e6f0fa] py-2 px-4 font-bold text-[#0d3d7a] text-xs tracking-widest border-b border-[#c5daf0]">PONTOS DE PREGAÇÃO (PP)</div>
                        <table className="w-full text-xs">
                           <thead><tr className="bg-[#f0f6ff]"><th className="p-2 border-b border-[#c5daf0]">TURNO/LOCAL</th><th className="p-2 border-b border-[#c5daf0]">ESCALADOS</th></tr></thead>
                           <tbody className="divide-y divide-[#c5d8ef]">
                              {escalaLocal.filter(l => l.categoria.includes("PP")).map((l, i) => (
                                <tr key={i} className="even:bg-slate-50">
                                  <td className="p-2 font-bold text-[#0d3d7a]">{l.data}: {l.local}</td>
                                  <td className="p-2 text-[10px]">{l.escalados.join(", ")}</td>
                                </tr>
                              ))}
                           </tbody>
                        </table>
                     </div>
                     <div className="bg-white border border-[#c5daf0] rounded-xl overflow-hidden shadow-sm">
                        <div className="bg-[#e6f0fa] py-2 px-4 font-bold text-[#0d3d7a] text-xs tracking-widest border-b border-[#c5daf0]">PORTARIA SEMANAL</div>
                        <table className="w-full text-xs">
                           <thead><tr className="bg-[#f0f6ff]"><th className="p-2 border-b border-[#c5daf0]">DATA/EVENTO</th><th className="p-2 border-b border-[#c5daf0]">ESCALADOS</th></tr></thead>
                           <tbody className="divide-y divide-[#c5d8ef]">
                              {escalaLocal.filter(l => !l.categoria.includes("PP") && l.categoria !== "C.O").map((l, i) => (
                                <tr key={i} className="even:bg-slate-50">
                                  <td className="p-2 font-bold text-[#0d3d7a]">{l.categoria}: {l.local}</td>
                                  <td className="p-2 text-[10px] font-medium text-slate-600">{l.escalados.join(", ")}</td>
                                </tr>
                              ))}
                           </tbody>
                        </table>
                     </div>
                  </div>
               </div>
            </div>
          )}

          {activeTab === "obreiros" && (
            <div className="local-section no-print shadow-xl animate-in fade-in zoom-in-95 duration-300">
               <div className="local-section-title flex justify-between items-center">
                  <span>👥 CADASTRO DE OBREIROS</span>
                  <div className="flex gap-2">
                    <button onClick={() => {
                       const nome = prompt("Nome do obreiro:");
                       const cargo = prompt("Cargo (Pr./Pb./Dc./Aux./Aux. Local.):");
                       const cong = prompt("Congregação:");
                       if(nome && cargo && cong) setObreiros([...obreiros, {nome, cargo, congregacao: cong}]);
                    }} className="bg-white/20 hover:bg-white/30 text-white px-4 py-1 rounded-full text-xs font-bold transition-all flex items-center gap-1">
                       <Plus size={14} /> Novo Obreiro
                    </button>
                  </div>
               </div>
               <div className="overflow-x-auto">
                 <table className="local-table w-full text-sm">
                   <thead className="bg-[#f0f6ff]">
                      <tr>
                        <th className="p-4 border-b border-[#c5daf0] text-blue-900">CARGO</th>
                        <th className="p-4 border-b border-[#c5daf0] text-blue-900 text-left">NOME COMPLETO</th>
                        <th className="p-4 border-b border-[#c5daf0] text-blue-900 text-left">CONGREGAÇÃO</th>
                        <th className="p-4 border-b border-[#c5daf0] text-blue-900 text-right text-xs">AÇÕES</th>
                      </tr>
                   </thead>
                   <tbody>
                      {obreiros.map((ob, idx) => (
                        <tr key={idx} className="hover:bg-blue-50/50 transition-colors">
                          <td className="p-4 text-center font-black text-blue-600 w-24">
                            <span className="bg-blue-100 px-3 py-1 rounded-full">{ob.cargo}</span>
                          </td>
                          <td className="p-4 font-bold text-slate-800">{ob.nome}</td>
                          <td className="p-4 text-xs font-semibold text-slate-400 uppercase tracking-tight">{ob.congregacao}</td>
                          <td className="p-4 text-right">
                             <div className="flex justify-end gap-1">
                                <button onClick={() => handleEditObreiro(idx)} className="p-1.5 text-blue-600 hover:bg-blue-100 rounded-lg transition-colors">✏️</button>
                                <button onClick={() => handleDeleteObreiro(idx)} className="p-1.5 text-red-600 hover:bg-red-100 rounded-lg transition-colors"><Trash2 size={14} /></button>
                             </div>
                          </td>
                        </tr>
                      ))}
                   </tbody>
                 </table>
               </div>
            </div>
          )}

          {activeTab === "calendario" && (
            <div className="local-section no-print shadow-xl animate-in fade-in zoom-in-95 duration-300">
               <div className="local-section-title flex justify-between items-center">
                  <span>📅 CALENDÁRIO GERAL 2026</span>
                  <button onClick={() => {
                     const data = prompt("Data (AAAA-MM-DD):");
                     const desc = prompt("Descrição:");
                     const cong = prompt("Congregação:");
                     if(data && desc && cong) setEventos([...eventos, { id: Math.random().toString(36).substr(2, 9), data, descricao: desc, congregacao: cong, cc: "" }]);
                  }} className="bg-white/20 hover:bg-white/30 text-white px-4 py-1 rounded-full text-xs font-bold transition-all flex items-center gap-1">
                     <Plus size={14} /> Novo Evento
                  </button>
               </div>
               <div className="p-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 bg-slate-50/30">
                  {eventos.map((ev, idx) => (
                    <div key={ev.id || idx} className="bg-white p-4 rounded-2xl border border-[#c5daf0] shadow-sm hover:border-blue-400 transition-all group">
                       <div className="flex justify-between items-start mb-2">
                          <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-[10px] font-black font-mono">{ev.data}</span>
                          <div className="flex gap-1">
                             <button onClick={() => handleEditEvento(idx)} className="text-blue-500 opacity-0 group-hover:opacity-100 transition-opacity">✏️</button>
                             <button onClick={() => handleDeleteEvento(ev.id)} className="text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"><Trash2 size={12}/></button>
                          </div>
                          <span className="text-[10px] text-slate-400 font-bold uppercase tracking-tighter">{ev.cc || "Setor 01"}</span>
                       </div>
                       <h4 className="font-bold text-slate-800 text-sm mb-1">{ev.descricao}</h4>
                       <div className="flex items-center gap-1 text-[10px] text-blue-500 font-bold">
                          <MapPin size={10} /> {ev.congregacao}
                       </div>
                    </div>
                  ))}
               </div>
            </div>
          )}

          {activeTab === "config" && (
            <div className="space-y-8 p-6 animate-in fade-in duration-500">
               {/* Scripts/Automation Panel */}
               <div className="bg-[#0e3d6e] p-8 rounded-3xl text-white shadow-xl relative overflow-hidden">
                  <div className="relative z-10">
                    <h3 className="text-2xl font-black mb-2 flex items-center gap-2 italic">
                       <RefreshCw size={28} /> AUTOMATIZAÇÃO DE ESCALAS
                    </h3>
                    <p className="text-white/60 mb-6 text-sm max-w-xl">Aplique as regras de códigos de culto baseadas na semana do mês para todas as congregações da escala oficial de uma só vez.</p>
                    <div className="flex gap-4">
                       <button onClick={aplicarRegrasGerais} className="bg-white text-[#0e3d6e] px-8 py-3 rounded-full font-black text-xs uppercase tracking-widest hover:bg-amber-400 hover:text-black transition-all shadow-lg">
                          🌀 Aplicar Regras à Semana Atual
                       </button>
                    </div>
                  </div>
                  <RefreshCw size={200} className="absolute -right-20 -bottom-20 text-white/5 rotate-12" />
               </div>

               <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  {/* Tipos de Culto */}
                  <div className="bg-white p-8 rounded-3xl border border-[#c5daf0] shadow-sm">
                    <h3 className="text-xl font-bold mb-6 text-[#0e3d6e] flex items-center gap-2 border-b pb-4 border-slate-100">
                      <Settings size={24} className="text-[#0d4a8a]" /> Tipos de Culto (Códigos)
                    </h3>
                    <div className="space-y-3">
                       {tiposCulto.map((tipo, idx) => (
                         <div key={idx} className="flex justify-between items-center bg-slate-50 p-4 rounded-2xl border border-slate-100 group">
                            <div>
                               <span className="bg-blue-600 text-white px-2 py-0.5 rounded text-[10px] font-mono mr-2">{tipo.codigo}</span>
                               <span className="font-bold text-slate-700">{tipo.nome}</span>
                            </div>
                            <button onClick={() => {
                               if(confirm("Excluir este tipo?")) {
                                  const nt = [...tiposCulto];
                                  nt.splice(idx, 1);
                                  setTiposCulto(nt);
                               }
                            }} className="text-red-400 opacity-0 group-hover:opacity-100 hover:text-red-600 transition-all"><Trash2 size={16}/></button>
                         </div>
                       ))}
                       <button onClick={() => {
                          const nome = prompt("Nome do culto:");
                          const codigo = prompt("Código:");
                          if(nome && codigo) setTiposCulto([...tiposCulto, {nome, codigo}]);
                       }} className="w-full py-4 border-2 border-dashed border-slate-200 rounded-2xl text-slate-400 font-bold hover:bg-slate-50 transition-all flex items-center justify-center gap-2">
                          <Plus size={18} /> Novo Tipo de Culto
                       </button>
                    </div>
                  </div>

                  {/* Regras Automation */}
                  <div className="bg-white p-8 rounded-3xl border border-[#c5daf0] shadow-sm">
                    <h3 className="text-xl font-bold mb-6 text-[#0e3d6e] flex items-center gap-2 border-b pb-4 border-slate-100">
                      <CheckCircle2 size={24} className="text-[#0d4a8a]" /> Regras de Culto por Semana
                    </h3>
                    <div className="space-y-3 max-h-[500px] overflow-y-auto pr-2 custom-scrollbar">
                       {regrasCulto.map((regra, idx) => (
                         <div key={idx} className="bg-slate-50 p-4 rounded-2xl border border-slate-100 group relative">
                            <div className="flex justify-between items-start mb-2">
                               <span className="text-[9px] font-black uppercase tracking-tighter text-blue-500">{regra.dia}</span>
                               <button onClick={() => handleDeleteRegra(idx)} className="text-red-300 opacity-0 group-hover:opacity-100 hover:text-red-500 transition-all"><Trash2 size={14}/></button>
                            </div>
                            <h5 className="font-bold text-slate-800 mb-2">{regra.congregacao}</h5>
                            <div className="flex gap-1">
                               {regra.regraSemana.map((w, wIdx) => (
                                 <div key={wIdx} className="flex-1 bg-white border border-slate-200 p-1 rounded text-center" title={`Semana ${wIdx+1}`}>
                                    <p className="text-[7px] text-slate-400 font-bold leading-none mb-1">S{wIdx+1}</p>
                                    <p className="text-[10px] font-black text-blue-600 leading-none">{w || "-"}</p>
                                 </div>
                               ))}
                            </div>
                         </div>
                       ))}
                       <button onClick={() => {
                          const cong = prompt("Nome da Congregação:");
                          const dia = prompt("Dia (segunda, terca, quarta, quintaNoite, sexta, sabado, domingoNoite):");
                          const w1 = prompt("1ª Semana (Nome do Culto):");
                          const w2 = prompt("2ª Semana (Nome do Culto):");
                          const w3 = prompt("3ª Semana (Nome do Culto):");
                          const w4 = prompt("4ª Semana (Nome do Culto):");
                          const w5 = prompt("5ª Semana (Nome do Culto):");
                          if(cong && dia) setRegrasCulto([...regrasCulto, {
                             congregacao: cong,
                             dia,
                             regraSemana: [w1||"", w2||"", w3||"", w4||"", w5||""]
                          }]);
                       }} className="w-full py-4 border-2 border-dashed border-slate-200 rounded-2xl text-slate-400 font-bold hover:bg-slate-50 transition-all flex items-center justify-center gap-2">
                          <Plus size={18} /> Nova Regra de Automação
                       </button>
                    </div>
                  </div>
               </div>

               <div className="grid grid-cols-1 md:grid-cols-2 gap-8 no-print">
                  <div className="bg-white p-8 rounded-3xl border border-[#c5daf0] shadow-sm">
                    <h3 className="text-xl font-bold mb-6 text-[#0e3d6e] flex items-center gap-2 border-b pb-4 border-slate-100">
                      <Database size={24} className="text-[#0d4a8a]" /> Google Sheets Sync
                    </h3>
                    <div className="space-y-6">
                      <div className={`p-6 rounded-2xl border-2 flex items-center justify-between ${isConfigured ? "bg-green-50 border-green-100" : "bg-red-50 border-red-100"}`}>
                        <div>
                          <p className={`font-black uppercase tracking-tighter text-lg ${isConfigured ? "text-green-700" : "text-red-700"}`}>
                            {isConfigured ? "CONECTADO" : "DESCONECTADO"}
                          </p>
                          <p className="text-xs opacity-60">Status da integração com a nuvem</p>
                        </div>
                        {isConfigured ? <CheckCircle2 className="text-green-500" size={40} /> : <AlertCircle className="text-red-500" size={40} />}
                      </div>
                      <div className="bg-slate-50 p-5 rounded-2xl text-xs text-slate-500 leading-relaxed border border-slate-100">
                        <p className="font-bold mb-2 text-slate-700">📌 DICA DE SINCRONIZAÇÃO:</p>
                        O sistema utiliza as abas: <b>Obreiros</b>, <b>Congregacoes</b>, <b>EscalaOficial</b>, <b>EscalaLocal</b>, <b>Eventos</b>, <b>TiposCulto</b> e <b>RegrasCulto</b> da sua planilha Google.
                      </div>
                      <div className="flex gap-4 items-center">
                        <button 
                          onClick={saveData} 
                          disabled={saving || loading}
                          className="flex-1 bg-[#0d4a8a] text-white py-4 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-[#1a5fa0] transition-all shadow-lg flex items-center justify-center gap-2"
                        >
                           <Save size={18} /> {saving ? "SALVANDO..." : "SALVAR TUDO NA NUVEM"}
                        </button>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white p-8 rounded-3xl border border-[#c5daf0] shadow-sm">
                    <h3 className="text-xl font-bold mb-6 text-[#0e3d6e] flex items-center gap-2 border-b pb-4 border-slate-100">
                      <MapPin size={24} className="text-[#0d4a8a]" /> Congregações Ativas
                    </h3>
                    <div className="flex flex-wrap gap-2">
                       {congregacoes.map((cong, idx) => (
                         <div key={idx} className="group relative">
                           <span className="px-4 py-2 bg-[#e6f0fa] text-[#0d4a8a] text-[10px] font-black rounded-full border border-[#c5daf0] uppercase tracking-tight shadow-sm hover:bg-blue-600 hover:text-white transition-all cursor-pointer">
                             {cong}
                           </span>
                           <button onClick={() => {
                              if(confirm("Excluir congregação " + cong + "?")) {
                                 const nc = [...congregacoes];
                                 nc.splice(idx, 1);
                                 setCongregacoes(nc);
                              }
                           }} className="absolute -top-1 -right-1 bg-red-500 text-white rounded-full p-0.5 opacity-0 group-hover:opacity-100 transition-opacity"><Trash2 size={8}/></button>
                         </div>
                       ))}
                       <button onClick={() => {
                          const nome = prompt("Nome da congregação:");
                          if(nome) setCongregacoes([...congregacoes, nome]);
                       }} className="px-4 py-2 border-2 border-dashed border-slate-200 text-slate-400 text-[10px] font-black rounded-full uppercase tracking-tight hover:bg-slate-50 transition-all">
                          + Adicionar
                       </button>
                    </div>
                  </div>
               </div>
            </div>
          )}
      </main>

      <footer className="mt-20 py-20 bg-[#0e3d6e] text-white/30 text-center text-xs no-print">
        <div className="max-w-7xl mx-auto px-4">
          <img 
            src="https://static.ieadpe.org.br/ieadpe_logo_colorido_pequeno.png" 
            alt="IEADPE Footer" 
            className="w-16 h-16 mx-auto mb-8 brightness-0 invert opacity-20" 
            referrerPolicy="no-referrer"
          />
          <p className="max-w-md mx-auto mb-4 italic">“Portanto, meus amados irmãos, sede firmes e constantes, sempre abundantes na obra do Senhor...” — 1 Co 15:58</p>
          <div className="h-px bg-white/10 w-32 mx-auto mb-4"></div>
          <p className="uppercase tracking-[2px] font-bold">IEADPE Filial Araçoiaba</p>
          <p className="mt-2">Sistema Interno de Gestão de Escalas - © 2026</p>
        </div>
      </footer>
    </div>
  );
}
